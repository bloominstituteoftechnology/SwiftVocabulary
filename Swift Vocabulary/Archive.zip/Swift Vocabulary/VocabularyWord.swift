//
//  VocabularyWord.swift
//  Swift Vocabulary
//
//  Created by Brandi on 10/7/19.
//  Copyright © 2019 Lambda School. All rights reserved.
//

import UIKit

struct VocabularyWord {
    let word: String
    let definition: String
}
